#!/bin/bash
cp -rf palette.ini ~/.config/far2l/
cp -rf colors.ini ~/.config/far2l/settings/
sed -i 's/ChangeBgEditor\=0/ChangeBgEditor\=1/g' ~/.config/far2l/plugins/colorer/config.ini
rm -rf ~/.config/far2l/plugins/colorer/base
cp -rf /usr/lib/far2l/Plugins/colorer/base ~/.config/far2l/plugins/colorer/
cp -rf hrd ~/.config/far2l/plugins/colorer/base/
sed -i 's/Catalog\=$/Catalog\=\~\/\.config\/far2l\/plugins\/colorer\/base\/catalog\.xml/g' ~/.config/far2l/plugins/colorer/config.ini
